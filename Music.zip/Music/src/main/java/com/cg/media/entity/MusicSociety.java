package com.cg.media.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
@Data
@Entity
public class MusicSociety {
	@Id
	private int composerMusicSocietyId;//---- Fixed ID's-------
	private String composerMusicSocietyName;
	public int getComposerMusicSocietyId() {
		return composerMusicSocietyId;
	}
	public void setComposerMusicSocietyId(int composerMusicSocietyId) {
		this.composerMusicSocietyId = composerMusicSocietyId;
	}
	public String getComposerMusicSocietyName() {
		return composerMusicSocietyName;
	}
	public void setComposerMusicSocietyName(String composerMusicSocietyName) {
		this.composerMusicSocietyName = composerMusicSocietyName;
	}

}
