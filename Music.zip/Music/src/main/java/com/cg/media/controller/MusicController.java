package com.cg.media.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.media.entity.Artist;
import com.cg.media.entity.ArtistSong;
import com.cg.media.entity.Composer;
import com.cg.media.entity.ComposerSong;
import com.cg.media.entity.MusicSociety;
import com.cg.media.entity.Song;
import com.cg.media.service.IComposerService;

@RestController
public class MusicController {
	@Autowired
	IComposerService iService;

	@RequestMapping("/Hello")
	public String GetAllComposer() {
		return "SayHello";

	}

	// ----------------List All Composer Details----------
	@RequestMapping(value = "/Composer", method = RequestMethod.POST)
	public Composer createComposer(@Valid  @RequestBody Composer composer) {
		
		return iService.createComposer(composer);

	}

	@RequestMapping("/Composer")
	public List<Composer> getAllComposer() {
		return iService.getAllComposer();

	}

//--------------Get Single Composer Details--------------
	@RequestMapping("/Composer/{composerId}")
	public Composer getOneComposer(@PathVariable int composerId) {
		return iService.getOneComposer(composerId);

	}

	@RequestMapping(value = "/Composer/{composerId}", method = RequestMethod.PUT)
	public Composer updateComposer(@RequestBody Composer composer, @PathVariable int composerId) {

		return iService.updateComposer(composer, composerId);

	}
	// ----------------------ALL ARTIST
	// DETAILS------------------------------------------------------------------

	// ----------Create Artist------
	@RequestMapping(value = "/Artist", method = RequestMethod.POST)
	public Artist createArtist(@RequestBody Artist artist) {
		return iService.createArtist(artist);

	}

	@RequestMapping("/Artist")
	public List<Artist> getAllArtist() {
		return iService.getAllArtist();

	}

	/*
	 * @RequestMapping(value="/Artist/{artistId}",method=RequestMethod.PUT) public
	 * Artist updateArtist(@RequestBody Artist artist,@PathVariable int artistId) {
	 * return iService.updateArtist(artist,artistId);
	 * 
	 * }
	 */

	@RequestMapping(value = "/Artist/{artistId}/{artistName}/{artistType}", method = RequestMethod.PUT)
	public Artist updateArtist(@PathVariable int artistId, @PathVariable String artistName,
			@PathVariable String artistType) {
		return iService.updateArtist(artistId, artistName, artistType);

	}

	// ---------------------MusicSociety Details-----------------------------------

	@RequestMapping(value = "/MusicSociety", method = RequestMethod.POST)
	public MusicSociety createMusicSociety(@RequestBody MusicSociety musicSociety) {
		return iService.createMusicSociety(musicSociety);
	}

	@RequestMapping("/MusicSociety")
	public List<MusicSociety> getAllMusicSociety() {
		return iService.getAllMusicSociety();

	}
	// ----------------ALL Song Details--------------------

	@RequestMapping(value = "/Song", method = RequestMethod.POST)
	public Song createSong(@RequestBody Song song) {
		return iService.createSong(song);

	}

	@RequestMapping("/Song")
	public List<Song> getAllSong() {
		return iService.getAllSong();

	}

	// -------------ALL ARTIST SONG DETAILS--------------------
	@RequestMapping(value = "/ArtistSong", method = RequestMethod.POST)
	public ArtistSong createArtistSong(@RequestBody ArtistSong artistSong) {
		return iService.createArtistSong(artistSong);

	}
	@RequestMapping("/ArtistSong")
	public List<ArtistSong> getAllArtistSong(){
		return iService.getAllArtistSong();
		
	}
	@RequestMapping("/ArtistSong/{artistSongId}")
	public ArtistSong getArtistSong(@PathVariable int artistSongId) {
		return iService.getArtistSong(artistSongId);
		
	} 

	// -=-------------ALL Composer SONG DEetails---------------
	@RequestMapping(value = "/ComposerSong", method = RequestMethod.POST)
	public ComposerSong createComposerSong(@RequestBody ComposerSong composerSong) {
		return iService.createComposerSong(composerSong);

	}

	@RequestMapping("/ComposerSong")
	public List<ComposerSong> getAllComposerSong() {
		return iService.getAllComposerSong();

	}
	@RequestMapping("/ComposerSong/{composerSongId}")
	public ComposerSong getComposerSong(@PathVariable int composerSongId) {
		
		return iService.getComposerSong(composerSongId);
		
		
	}
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(
			MethodArgumentNotValidException ex) {
	    Map<String, String> errors = new HashMap<>();
	    ex.getBindingResult().getAllErrors().forEach((error) -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        errors.put(fieldName, errorMessage);
	    });
	    return errors;
	} 
	
}
